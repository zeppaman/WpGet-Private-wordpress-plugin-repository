<?php
/**
 * Plugin Name: My plugin Test
 * Plugin URI: https://github.com/zeppaman/WpGet
 * Author URI: https://github.com/girardengo
 * Version: 2.0.0
 * Author: Francesco Minà
 * Description: My plugin Test
 * Text Domain: my-plugin-test
 * Domain Path:  
 *
 * PHP versions 7
 * 
 * @category  
 * @package   
 * @author    Francesco Minà <girardengo@gmail.com>
 * @copyright 2018 Francesco Minà
 * @license   GNU General Public License v3.0
 * @version   2.0.0
 * @link      https://github.com/zeppaman/WpGet
*/

// esco se non ho caricato wp
if( !defined( 'ABSPATH' ) )	exit();

error_log('load my test plugin...');

// remember to set variables (es in wp-config.php file) before use this file
require_once( 'WpGetUpdater.php' );
