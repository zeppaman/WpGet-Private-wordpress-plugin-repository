<?php
/**
 * Plugin Name: My plugin Test
 * Plugin URI: https://github.com/zeppaman/WpGet
 * Author URI: https://github.com/girardengo
 * Version: 3.7.0
 * Author: Francesco Minà
 * Description: My plugin Test
 * Text Domain: my-plugin-test
 * Domain Path:  
 */

// wp or die!
if( !defined( 'ABSPATH' ) )	exit();

error_log('load my test plugin...');

// remember to set variables (es in wp-config.php file) before use this file

// // repository config data
// define( 'WPGET_REPO_SLUG','test000' );
// define( 'WPGET_PACKAGE_NAME','my-plugin' );
// define( 'WPGET_API_URL','http://localhost:3000/web/' );
// define( 'WPGET_TOKEN_READ','FnrvNuzwKodEgIqxsBctbFc2SxMncM');

// // plugin info
// // plugin filename
// define( 'WPGET_PLUGIN_FILE', 'plugin-test.php' );
// // plugin directory
// define( 'WPGET_PLUGIN_DIR', 'plugin-test' );

require_once( 'WpGetUpdater.php' );
