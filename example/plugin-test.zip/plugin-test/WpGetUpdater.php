<?php
namespace WpGet\Updater;

class WpGetUpdater {

    

    /**
     * Plugin file (plugin_file.php)
     * @var string
     */
    public $plugin_file;

    /**
     * Plugin directory (plugin_directory)
     * @var string
     */
    public $plugin_dir;
    
    /**
     * Plugin WP Slug (plugin_directory/plugin_file.php)
     * @var string
     */
    public $plugin_basename;

    /**
     * Plugin slug
     * @var string
     */
    public $plugin_slug;


    /**
     * Plugin file data
     *
     * @var array
     */
    private $plugin_file_data;

    /**
     * wpget url API
     *
     * @var url
     */
    private $wpget_api_url;

    /**
     * wpget Repository Slug
     *
     * @var url
     */
    private $wpget_repo_slug;
    
    /**
     * wpget Package Name
     *
     * @var url
     */
    private $wpget_package_name;
    
    /**
     * WPGet read Token
     *
     * @var string
     */
    private $token;

  
  
    
    function __construct(  )
    {  
        $this->init_vars();

        add_filter( "pre_set_site_transient_update_plugins", array( $this, "wpget_pre_set_site_transient_update_plugins" ) );
        add_filter( "plugins_api", array( $this, "wpget_plugins_api" ), 10, 3 );

        // add_filter( "plugins_api_result", array( $this, "wpget_plugins_api_result"), 10,3); 
        // add_filter( "plugins_api_args", array( $this, "wpget_plugins_api_args"), 10,2); 
        
        // after updare
        //add_filter( "upgrader_post_install", array( $this, "wpget_upgrader_post_install" ), 10, 3 );
        
        // message after upgrade
        //add_action( 'in_plugin_update_message-' . $this->plugin_slug, array( $this, 'wpget_in_plugin_update_message' ) );

        
    }
    /**
     * Initialize variables
     *
     * @return void
     */
    private function init_vars()
    {
        $abs_path = path_join( path_join( WP_PLUGIN_DIR, WPGET_PLUGIN_DIR ), WPGET_PLUGIN_FILE );
        $path_parts = pathinfo($abs_path);

        $this->get_plugin_file_data( $abs_path );

        // plugin vars
        $this->plugin_dir           = WPGET_PLUGIN_DIR;
        $this->plugin_file          = WPGET_PLUGIN_FILE;
        $this->plugin_basename      = plugin_basename( $abs_path ); 
        $this->plugin_slug          = $path_parts['filename'];

        // repo vars
        $this->token                = WPGET_TOKEN_READ;
        $this->wpget_api_url        = WPGET_API_URL . 'Catalog/Package';
        $this->wpget_package_name   = WPGET_PACKAGE_NAME;
        $this->wpget_repo_slug      = WPGET_REPO_SLUG;


    }

    private function get_plugin_file_data($abs_path)
    {
        $default_headers = array(
            'Plugin Name'   => 'Plugin Name',
            'Plugin URI'    => 'Plugin URI',
            'Version'       => 'Version',
            'Description'   => 'Description',
            'Author'        => 'Author',
            'Author URI'    => 'Author URI',
            'Text Domain'   => 'Text Domain',
            'Domain Path'   => 'Domain Path',
            'Network'       => 'Network',
            
        );


        $this->plugin_file_data = get_file_data($abs_path, $default_headers, 'plugin');

    }

    

    // function wpget_plugins_api_result($res, $action, $args )
    // {
    //     error_log("***************** FUNCTION: " .__FUNCTION__);
    //     return $res;
    // }

    // function wpget_plugins_api_args($args, $action )
    // {
    //     error_log("***************** FUNCTION: " .__FUNCTION__);
    //     return $args;
    // }
    
    // function wpget_upgrader_post_install($response, $hook_extra, $result)
    // {
    //     //error_log("***************** FUNCTION: " .__FUNCTION__);
    //     // Remember if our plugin was previously activated
    //     $was_activated = is_plugin_active( PLUGIN_SLUG );

    //     global $wp_filesystem;
    //     $plugin_folder = WP_PLUGIN_DIR . DIRECTORY_SEPARATOR . dirname( PLUGIN_SLUG );
    //     $wp_filesystem->move( $result['destination'], $plugin_folder );
    //     $result['destination'] = $plugin_folder;

    //     // Re-activate plugin if needed
    //     if ( $was_activated )
    //     {
    //         $activate = activate_plugin( PLUGIN_SLUG );
    //     }
        
    //     return $result;

    // }

    // function wpget_in_plugin_update_message()
    // {
    //     //error_log("***************** FUNCTION: " .__FUNCTION__);
    //     //echo 'message after update';
    // }
    
    public function get_remote_info( $version = '' )
    {
        $url = add_query_arg( array(
            'name'      => $this->wpget_package_name,
            'version'   => $version,
            'reposlug'  => $this->wpget_repo_slug
            ), 
            $this->wpget_api_url
        );

        $args = array(
            'headers'     => array('Authorization' => 'Bearer ' . $this->token ),
        ); 

        $response = wp_remote_get( $url ,$args);
        
        if ( ! is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) === 200 )
        {
            if ($response['response']['code'] == '200')
            {
                $body = json_decode( $response['body'] );         
                return !empty($body) ? $body : null ;    
            }
            else
            {
                error_log("Error code: " . $response['response']['code'] . ', message error: ' . $response['response']['message'] );
                return null;
            }
        }

        return null;
    }
        
  
    function transient_info($plugin_info)
    {
        $transient = new \stdClass();

        $transient->slug            = $this->plugin_slug;
        $transient->plugin          = $this->plugin_basename;

        $transient->new_version     = $plugin_info->version;
        $transient->url             = $plugin_info->homepage; // plugin url
        $transient->package         = $plugin_info->relativepath; //  path to file zip


        $transient->icons           = array(
            '1x'            => $plugin_info->icons_1x,
            '2x'            => $plugin_info->icons_2x,
            'default'       => $plugin_info->icons_default,

        );

        $transient->banners         = array(
            'low'           => $plugin_info->banners_low,
            'high'          => $plugin_info->banners_high,
        );

        $transient->banners_rtl     = array();
        $transient->tested          = $plugin_info->tested;
        $transient->compatibility   = new \stdClass();


        return $transient;
    }

    // Push in plugin version information to get the update notification
    public function wpget_pre_set_site_transient_update_plugins( $transient )
    {
        if ( empty( $transient->checked ) )
        {
			return $transient;
        }

        // Get the remote version
        $remote_info = $this->get_remote_info();
        error_log(print_r($remote_info,true));
        // If a newer version is available, add the update
        if ( $remote_info  &&  version_compare( $this->plugin_file_data['Version'], $remote_info->version, '<' ) )
        {
            
            $transient->response[$this->plugin_basename] = $this->transient_info($remote_info);
       
        }

        return $transient;
    }

    /**
     * Function called in plugin version information to display in the details lightbox
     *
     * @param [type] $false
     * @param [type] $action
     * @param [type] $response
     * @return void
     */
    public function wpget_plugins_api( $false, $action, $response )
    {
        if ( empty( $response->slug ) || $response->slug != $this->plugin_slug )
        {
            return $false;
        }

        // Get the remote version
        $remote_info = $this->get_remote_info();
        error_log(print_r($remote_info,true));
        // If a newer version is available, add the update
        if ( $remote_info  &&  version_compare( $this->plugin_file_data['Version'], $remote_info->version, '<' ) )
        {
            $plugin_info = $this->transient_info($remote_info);
            // add section

            $plugin_info->sections = array(
                'description'       => $remote_info->description,
                'installation'      => $remote_info->installation,
                'faq'               => $remote_info->faq,
                'changelog'         => $remote_info->changelog,
                'old_version'       => $remote_info->old_version
            );

            // other info
            $plugin_info->name             = $this->plugin_file_data['Plugin Name']; // the name to visualize in preview
            $plugin_info->upgrade_notice   = $remote_info->upgrade_notice;

            $plugin_info->author           = $remote_info->author;
            $plugin_info->author_profile   = $remote_info->author_profile;
            $plugin_info->requires_php     = $remote_info->requires_php;
            $plugin_info->requires         = $remote_info->requires;
            $plugin_info->added            = $remote_info->added;
            $plugin_info->homepage         = $remote_info->homepage;

            return $plugin_info;
        }
       
        return $false;
        
    }
}

new \WpGet\Updater\WpGetUpdater();

?>